Abre **Jugar.exe**: elige nombre y modo en una pantalla grafica, sin consola. [Controles actuales](native/ALPHA.md), [conexion y chat](native/MULTIPLAYER.md), [terrenos](native/TERRENO.md).

## Alpha de autonomia y visitas multijugador

Abre Jugar-Alpha.bat para jugar o Jugar-Multijugador.bat para conectar dos islas por IP. El panel contiene poderes divinos; los habitantes deciden sus trabajos. Hay diplomacia, saqueo y un elegido que nace tras nueve meses del calendario del juego. Alcance, controles y limites: [ALPHA](native/ALPHA.md) y [multijugador](native/MULTIPLAYER.md).

# Isla Viva

Alpha C++ de desarrollo: [funciones y controles actuales](native/ALPHA.md). [Paquete portable](releases/IslaViva-alpha-wip.zip). El aspecto del mapa sigue en desarrollo y no esta aprobado como reproduccion identica de la referencia.

Para abrir directamente la alpha con el mapa recreado, usa **Jugar-Alpha.bat**. Detalles y limites del mapa: [native/MAPA.md](native/MAPA.md). El proyecto Godot original esta apartado en `legacy/godot/project.godot`.

Abre **Jugar.bat** para compilar y ejecutar el port C++ con los datos importados. Requiere CMake y Visual Studio 2022 con C++. Consulta [la integraci�n nativa](native/INTEGRACION.md) para el alcance, controles y pruebas. `Jugar-Godot.bat` conserva el arranque anterior si dispones del ejecutable Godot correspondiente.

## Versi�n anterior en Godot

Las secciones siguientes describen la versi�n Godot; el port C++ todav�a no incluye todas esas funciones.

## Presentaci�n y controles

La ventana es **sin bordes ni barra de t�tulo**. La interfaz est� dentro del juego y tiene controles propios; no utiliza temas, controles, fuentes ni iconos predeterminados de Godot. El texto pixelado se compone con un p�xel del atlas original. Los terrenos, personajes, animales y construcciones usan sus celdas de 8�8, ampliadas con nearest.

El mapa es una isla compacta dise�ada por zonas: aldea, lago y r�o, bosques con claros, monta�as, campos, playas y caminos conectados con curvas, cruces y puentes. La vista inicial ampl�a los sprites a escala entera 2�. Los habitantes usan las personas de `MAS-Characters-P8.png` y `MAS-Characters-DB.png`; el personaje anterior ya no aparece.

- **Retratos / clic en un habitante / Tab:** cambiar la persona inspeccionada. Su nombre, intenci�n, inventario y seis necesidades aparecen en el panel inferior.
- **Necesidades:** tienen nombre y valor num�rico. Pasar el rat�n o hacer clic explica qu� significan y c�mo se satisfacen.
- **Clic en trigo:** abre el estado real de la parcela, crecimiento, cosechas completadas y trabajador actual.
- **Clic en un animal:** identifica la especie y su relaci�n con la caza.
- **PAUSA / Espacio:** detener o continuar el tiempo.
- **1�, 4�, 12�, 32� / teclas 1�4:** cambiar velocidad.
- **SEGUIR / ISLA / F / rueda:** seguir al habitante seleccionado o volver al mapa completo.
- **DIARIO / J:** ver las acciones recientes realizadas por los habitantes.
- **GUARDAR / F5 y CARGAR / F9:** persistir o recuperar la partida.
- **SALIR / Esc:** guardar y cerrar. **F11:** alternar pantalla completa.

Los clics de inspecci�n no dan �rdenes de movimiento. Todos los habitantes deciden por s� mismos.

## Agricultura conectada con la vida de la aldea

Cada celda cultivada tiene estado persistente: tierra preparada, sembrada, creciendo o madura. La apariencia cambia con ese estado.

1. Un agricultor reserva una parcela accesible; otro no puede trabajar simult�neamente el mismo lugar.
2. Sembrar consume **una semilla del inventario**.
3. El trigo pasa por brote, crecimiento y maduraci�n. Tarda 120 segundos simulados de crecimiento; de noche crece m�s despacio.
4. Cosechar retira el trigo visible y produce **3 de grano y 2 semillas**. Un cultivo inmaduro no puede cosecharse.
5. Los habitantes llevan la cosecha al granero y conservan provisiones. Otros habitantes retiran grano de ese almac�n para comer. Comer consume una unidad y aumenta la saciedad.
6. Los agricultores vuelven a sembrar la tierra cosechada y preparan **parcelas nuevas**, gradualmente, en suelo cercano apto. No pueden cultivar encima de caminos, edificios, �rboles o agua. La ampliaci�n est� limitada a 24 celdas adicionales en esta versi�n.
7. El grano maduro no recogido se pierde con el tiempo. Con suficientes reservas, reducen la siembra; la prioridad de cosecha protege las reservas de semillas.

No se suman comida o semillas simplemente por estar en un bosque o sobre un campo. Inventario, almac�n, producci�n y consumo est�n conectados y sus cantidades se verifican en las pruebas.

## Supervivencia aut�noma

Hay seis habitantes con personalidad, hambre, sed, energ�a, sociabilidad, diversi�n, higiene, salud y relaciones. Cazan animales del bosque para obtener raciones; la fauna se desplaza y repuebla gradualmente. Buscan agua dulce en orillas accesibles, se lavan, conversan, exploran y comercian madera. La sed o el hambre urgente pueden interrumpir otras tareas.

Lejos de la aldea, el cansancio puede llevarlos a recolectar madera y montar un campamento: recolectar da cuatro unidades y construir consume tres. Los campamentos permanecen y pueden reutilizarse. El ciclo d�a/noche cambia gradualmente la iluminaci�n y las prioridades de descanso. Un d�a dura cinco minutos a velocidad normal.

## Guardado

El guardado conserva necesidades, inventarios, relaciones, fauna, hora, campamentos, parcelas ampliadas, etapas de crecimiento, historial de cosechas y grano comunitario. Se realiza cada 45 segundos reales y al cerrar normalmente.

Esta versi�n usa `user://isla_viva_v2.json`. El archivo de la primera versi�n no se sobrescribe: sus posiciones corresponden a otro mapa. En Windows, `user://` est� dentro de `%APPDATA%\Godot\app_userdata\DUNGEON SIMS � Isla viva`.

## Verificaci�n

Desde PowerShell, en la ra�z:

```powershell
.\godot\Godot_v4.7.2-stable_win64_console.exe --headless --path legacy/godot --script res://tests/simulation_test.gd
.\godot\Godot_v4.7.2-stable_win64_console.exe --headless --path legacy/godot --script res://tests/farming_test.gd
.\godot\Godot_v4.7.2-stable_win64_console.exe --path legacy/godot --script res://tests/presentation_test.gd
```

Las suites verifican supervivencia durante doce d�as, obst�culos, caza, agua, campamentos, conservaci�n de semillas y grano, expansi�n agr�cola, ciclos repetidos, guardado y controles mediante eventos de rat�n. La �ltima abre una ventana breve y comprueba tambi�n el modo sin decoraci�n y la selecci�n de los atlas correctos.

La simulaci�n todav�a es una base: no incluye interiores habitables, familias ni la complejidad completa de Los Sims. Las tareas de construcci�n de campamentos, comercio y relaciones son sencillas. El mundo solo avanza mientras est� abierto.

Assets: **Aleksandr Makarov / IKnowKingRabbit**, Micro Asset Series. Se conservan todos los originales de `Res` y su `license.txt`. No se descargaron recursos gr�ficos externos.



